﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Andres_Floor_cost_calculator
{
	class Program
	{
		static void Main(string[] args)
		{
			double installCost = 35.75;
			double installPerHour = 40;

			Console.WriteLine("Andres's Flooring Cost Estimator:");

			Console.WriteLine("									");

			Console.Write("Please enter length of floor:");
			string input=Console.ReadLine();
			int length = Int32.Parse(input);

			Console.Write("Please enter width of floor:");
			string input1 = Console.ReadLine();
			int width = Int32.Parse(input1);

			Console.Write("Please enter the cost per square foot for the flooring selected:");
			string input2 = Console.ReadLine();
			double squareFoot = double.Parse(input2);

			Console.WriteLine("----------------------------------");

			int totalFloorSize = length * width;
			double totalFlooringCost = length * width * squareFoot;
			double time = totalFloorSize / installPerHour;
			double labor = time * installCost;
			double totalCost = labor + totalFlooringCost;

			Console.WriteLine("For a total floor size of " + totalFloorSize + " the Flooring cost is: " + "$" + totalFlooringCost);
			Console.WriteLine("It will take " + time + " hours to install the floor at a cost of: " + "$" + labor);
			Console.WriteLine("									");
			Console.WriteLine("The Total finished cost for the new floor is: " + "$" + totalCost);
			Console.ReadLine();
		}
	}
}
